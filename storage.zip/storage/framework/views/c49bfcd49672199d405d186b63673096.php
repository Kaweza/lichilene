<!-- resources/views/admin/view-enrollment.blade.php -->
  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Enrollment</title>
    
    <!-- Bootstrap CSS (CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .container {
            margin-top: 20px;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .alert-success {
            text-align: center;
        }

        .table th {
            background-color: #007bff;
            color: white;
            text-align: center;
        }

        .table td {
            text-align: center;
        }

        .btn {
            margin-right: 5px;
        }

        @media (max-width: 768px) {
            .table-responsive {
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
     
    <div class="container">
        <h1 class="text-center">Student Enrollment List</h1>

        <!-- Success Message -->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Student Name</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Nationality</th>
                        <th>Guardian Name</th>
                        <th>Guardian Phone</th>
                        <th>Guardian Email</th>
                        <th>Relationship</th>
                        <th>Guardian Address</th>
                        <th>Entry Level</th>
                        <th>Previous School</th>
                        <th>Allergies</th>
                        <th>Medical Conditions</th>
                        <th>Emergency Name</th>
                        <th>Emergency Phone</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($student->student_name); ?></td>
                            <td><?php echo e($student->dob); ?></td>
                            <td><?php echo e($student->gender); ?></td>
                            <td><?php echo e($student->nationality); ?></td>
                            <td><?php echo e($student->guardian_name); ?></td>
                            <td><?php echo e($student->guardian_phone); ?></td>
                            <td><?php echo e($student->guardian_email); ?></td>
                            <td><?php echo e($student->relationship); ?></td>
                            <td><?php echo e($student->guardian_address); ?></td>
                            <td><?php echo e($student->entry_level); ?></td>
                            <td><?php echo e($student->previous_school); ?></td>
                            <td><?php echo e($student->allergies); ?></td>
                            <td><?php echo e($student->medical_conditions); ?></td>
                            <td><?php echo e($student->emergency_name); ?></td>
                            <td><?php echo e($student->emergency_phone); ?></td>
                            <td>
                                <!-- Edit Button -->
                                <a href="<?php echo e(route('admin.edit-student', $student->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                                <!-- Delete Button (with confirmation) -->
                                <form action="<?php echo e(route('admin.delete-student', $student->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this student?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div> <br><br>
        <a href="<?php echo e(route('dashboard')); ?>" class="nav-item nav-link">Back to home</a>     
    </div>
    </div>
    <!-- Bootstrap JS (for responsive behavior) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH D:\vue\kazi\tumainiAcademy\resources\views/admin/view-enrollment.blade.php ENDPATH**/ ?>