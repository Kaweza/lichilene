<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 84" <?php echo e($attributes); ?>>
    <image href="archive/tumaini_logo.jpg" width="80" height="84" />
</svg>
<?php /**PATH D:\vue\kazi\tumainiAcademy\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>