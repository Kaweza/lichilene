<div class="flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground">
    <img src="archive/tumaini_logo.jpg" 
         alt="Tumaini English Medium Academy Logo" 
         class="size-100 rounded-md" />
</div>
<div class="ml-1 grid flex-1 text-left text-sm">
    <span class="mb-0.5 truncate leading-none font-semibold">Tumaini Academy</span>
</div>
<?php /**PATH D:\vue\kazi\tumainiAcademy\resources\views/components/app-logo.blade.php ENDPATH**/ ?>